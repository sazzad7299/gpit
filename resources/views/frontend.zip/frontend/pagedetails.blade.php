@section('meta_box')
{!!$post->meta_box!!}
@endsection
@extends('frontend.master')

@section('content')

<!-- Modal -->
<div class="modal fade contact" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <form class="rt-form" method="POST" action="{{ route('apply.store') }}">
            @csrf
            <div class="modal-content">
                <div class="modal-header primary-background">
                    <h5 class="modal-title" id="exampleModalLabel">We will contact soon, Fill Now</h5>
                    <button type="button" class="btn-close btn btn-sm btn-danger" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body secondary-background">
                    <div class="form-group">
                        <label for="recipient-name" class="col-form-label">Name:</label>
                        <input type="text" class="form-control pill rt-mb-15" placeholder="Enter your full name" name="a_name">

                    </div>
                    <div class="form-group">
                        <label for="message-text" class="col-form-label">Number:</label>
                        <input type="text" class="form-control pill rt-mb-15" placeholder="Enter your phone number" name="a_number" required>
                    </div>

                    <div class="form-group">
                        <label for="message-text" class="col-form-label">Email:</label>
                        <input type="text" class="form-control pill rt-mb-15" placeholder="Enter your email" name="email">
                    </div>
                    @if($sposts->page_id == 76)
                    <div class="form-group">
                        <label for="message-text" class="col-form-label">Select course attendance type:</label> <br>
                        <input type="radio"  name="attendance_type" value="offline">
                        <label for="offline">Offline</label>
                        <input type="radio"name="attendance_type" value="online">
                        <label for="Online">Online</label>
                    </div>
                    @endif
                    <div class="form-group">
                        <label for="message-text" class="col-form-label">City:</label>
                      <select name="city" class="form-control pill rt-mb-15">
                        <option value="Dhaka">Dhaka</option>
                        <option value="Chattogram">Chattogram</option>
                        <option value="Khulna">Khulna</option>
                        <option value="Sylhet">Sylhet</option>
                        <option value="Mymensingh">Mymensingh</option>
                        <option value="Rangpur">Rangpur</option>
                        <option value="Barisal">Barisal</option>
                        <option value="Cumilla">Cumilla</option>
                      </select>
                    </div>
                    <input type="hidden" class="form-control pill rt-mb-15" placeholder="Number" name="a_country" value="{{ $sposts->name}}">
                </div>
                <div class="modal-footer primary-background">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary btn-exclusive">Submit</button>
                </div>
            </div>
        </form>

    </div>
</div>
<div class="container-fluid">
    <div class="row page-header">
        <div class="d-flex flex-column justify-content-center text-light" data-aos="zoom-out" style="background-image:url({{asset('frontend/images/pageheader.webp')}});background-size:cover;min-height:250px;text-align:center;color:#ffffff">
            <h1 class="text-light">{{$sposts->name}}</h1>

        </div>
    </div>
</div>
@php

@endphp
<section>
    <div class="container">
        <div class="card">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <img src="{{ asset('uploads/website/' . $sposts->image) }}" alt="" class="img-fluid">
                    </div>
                    <div class="col-md-6 d-flex flex-column justify-content-center">
                        <div class="about-content ps-0 ps-lg-3">
                            <p>{!! $sposts->short_description !!}</p>
                            @if ($sposts->button!=null)
                            <div class="col-md-3">
                                <button type="button" class="btn btn-primary btn-exclusive" data-bs-toggle="modal" data-bs-target="#exampleModal">{{$sposts->button}}</button>

                            </div>
                            @endif
                        </div>
                    </div>
                    <hr style="height: 5px; background-color: #000; border: none; margin-top:20px">
                    <div class="card-content" data-aos="fade-up" data-aos-delay="100">

                    {!!$sposts->description!!}
                </div>
                </div>
            </div>
        </div>
    <div class="d-flex justify-content-center" style="margin-top:50px">
        <a href="{{ url('/get-free-quate') }}" class="btn btn-primary free_quate_button" >Get A Free Quate <i class="bi bi-arrow-right"></i></a>
    </div>
    </div>
</section>
@endsection
